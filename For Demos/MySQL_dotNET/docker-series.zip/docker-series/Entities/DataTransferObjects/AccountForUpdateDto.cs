﻿using System;

namespace Entities.DataTransferObjects
{
	public class AccountForUpdateDto
	{
		public DateTime DateCreated { get; set; }
		public string AccountType { get; set; }
	}
}
