﻿using System;

namespace Entities.DataTransferObjects
{
	public class AccountForCreationDto
	{
		public DateTime DateCreated { get; set; }
		public string AccountType { get; set; }
	}
}
